package kronos.project

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import kotlinx.browser.document
import kronos.project.map.MapMarker
import kronos.project.map.WebMapHandle
import kronos.project.map.createBucharestMap
import org.w3c.dom.HTMLElement

private const val mapContainerId = "gel-map"
private const val mapWrapperId = "gel-map-wrapper"

private data class MapContainerRef(
    val element: HTMLElement,
    val createdByCompose: Boolean,
)

private data class MapWrapperRef(
    val element: HTMLElement,
    val createdByCompose: Boolean,
)

@Composable
actual fun PlatformMapHost(
    modifier: Modifier,
    markers: List<MapMarker>,
    onMapClick: (Double, Double) -> Unit,
) {
    val wrapperRef = remember { ensureMapWrapper(mapWrapperId) }
    val containerRef: MapContainerRef = remember { ensureMapContainer(mapContainerId, wrapperRef.element) }

    var mapHandle by remember { mutableStateOf<WebMapHandle?>(null) }
    val onMapClickState = rememberUpdatedState(onMapClick)

    // Compose draws a sized box; wrapper/container are DOM nodes used by MapLibre.
    Box(modifier = modifier.fillMaxSize()) {}

    LaunchedEffect(Unit) {
        // Make sure wrapper/container track full size.
        wrapperRef.element.style.width = "100%"
        wrapperRef.element.style.height = "100%"
        wrapperRef.element.style.position = "absolute"
        wrapperRef.element.style.top = "0"
        wrapperRef.element.style.right = "0"
        wrapperRef.element.style.bottom = "0"
        wrapperRef.element.style.left = "0"

        containerRef.element.style.width = "100%"
        containerRef.element.style.height = "100%"

        mapHandle = createBucharestMap(containerRef.element.id)
    }

    LaunchedEffect(mapHandle, markers) {
        mapHandle?.setMarkers(markers)
    }

    LaunchedEffect(mapHandle) {
        mapHandle?.setMapClickHandler { lat, lng -> onMapClickState.value(lat, lng) }
    }

    DisposableEffect(Unit) {
        onDispose {
            mapHandle?.destroy()
            mapHandle = null
            // Clean only nodes we created.
            if (containerRef.createdByCompose) containerRef.element.remove()
            if (wrapperRef.createdByCompose) wrapperRef.element.remove()
        }
    }
}

@Composable
actual fun rememberLocationPermissionGranted(): Boolean = true

private fun ensureMapWrapper(id: String): MapWrapperRef {
    val root = document.getElementById("root") as? HTMLElement
    val host = root ?: (document.body as? HTMLElement)
        ?: error("Missing document.body")

    val existing = document.getElementById(id) as? HTMLElement
    if (existing != null) {
        return MapWrapperRef(existing, createdByCompose = false)
    }

    val wrapper = document.createElement("div") as HTMLElement
    wrapper.id = id

    // Attach inside root if present.
    host.appendChild(wrapper)
    return MapWrapperRef(wrapper, createdByCompose = true)
}

private fun ensureMapContainer(id: String, parent: HTMLElement): MapContainerRef {
    val existing = document.getElementById(id) as? HTMLElement
    if (existing != null) {
        // If it's somewhere else, move it under our wrapper (safe for navigation).
        if (existing.parentElement != parent) {
            parent.appendChild(existing)
        }
        return MapContainerRef(existing, createdByCompose = false)
    }

    val container = document.createElement("div") as HTMLElement
    container.id = id
    parent.appendChild(container)
    return MapContainerRef(container, createdByCompose = true)
}
